# Plugin coding: Enes5519 & Driesboy
# Only works on PMMP and BlueLight

### API3 -> https://github.com/NL-4-DEVS/Eggwars/tree/API3

[![Poggit-CI](https://poggit.pmmp.io/ci.badge/NL-4-DEVS/Eggwars/Eggwars)](https://poggit.pmmp.io/ci/NL-4-DEVS/Eggwars/Eggwars)

Hi, the installation of the plugin I'm telling you now.

### Note: You do not change the colors of the text on the sign. (Professionals can change)

## EGG WARS SHOP
### - EggWars Shop Setup: /ew shop (Villager creates.)

## EGG WARS GENERATOR
### EggWars Generator Setup with Sign;

### Iron Generator;
#### First Line: generator
#### Second Line: Iron

### Gold Generator;
#### First Line: generator
#### Second Line: Gold
#### Third Line: Broken (If break generator)

### Diamond Generator;
#### First Line: generator
#### Second Line: Diamond
#### Third Line: Broken

## EGG WARS TEAM EGG SETUP
### Place the Team Color Wool and put the Egg on top.
